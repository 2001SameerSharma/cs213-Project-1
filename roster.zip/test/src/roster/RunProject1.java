package roster;
import java.util.Scanner;
public class RunProject1 {
    public static void main(String[] args) {
        new RosterManager().run();

    }
}