package roster;
import java.util.Scanner;
public class RosterManager {

    public void run(){
        System.out.println("Roster Manager running...");
        Scanner sc = new Scanner(System.in);
        while(sc.hasNextLine()){
            String operation = sc.next();
            if(operation.equals(a)){
                String first = sc.next();
                String last = sc.next();
                String date = sc.next();
                String major = sc.next();
                System.out.println(date);
            }
            if(operation.equals("Q")){
                System.out.println("Roster Manager terminated.");
                break;
            }
        }
    }




}
