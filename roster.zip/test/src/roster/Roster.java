package roster;

public class Roster {
    private Student[] roster;
    private int size;


    //search the given student in roster
    private int find(Student student) {}

    //increase the array capacity by 4
    private void grow() {}
    public boolean add(Student student){}

    //add student to end of array
    public boolean remove(Student student){}//maintain the order after remove
    public boolean contains(Student student){} //if the student is in roster
    public void print () {} //print roster sorted by profiles
    public void printBySchoolMajor() {} //print roster sorted by school major
    public void printByStanding() {} //print roster sorted by standing
}