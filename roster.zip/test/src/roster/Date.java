package roster;
import java.util.Calendar;

public class Date implements Comparable<Date> {
    private int year;
    private int month;
    private int day;
    public static final int QUADRENNIAL = 4;
    public static final int CENTENNIAL = 100;
    public static final int QUATERCENTENNIAL = 400;
    public static final int FIRST_ENTRY = 1;
    public Date(){
        Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH)+1;
        day = c.get(Calendar.DAY_OF_MONTH);
    } //create an object with today’s date (see Calendar class)
    public Date(String date) {
        year = Integer.parseInt(date.substring(6));
        month = Integer.parseInt(date.substring(0,2));
        day = Integer.parseInt(date.substring(3,5));
    } //take “mm/dd/yyyy” and create a Date object
    public boolean isValid() {
        if(year < 0 || year > Calendar.YEAR){
            return false;
        }
        if(month < 1 || month > Calendar.DECEMBER+1){
            return false;
        }
        if(day < 1){
            return false;
        }

        if(month == 2){
            boolean leap = false;
            if(year % QUADRENNIAL == 0){
                if(year % CENTENNIAL != 0 || year % QUATERCENTENNIAL == 0 ){
                    leap = true;
                }
            }
            if(leap){
                if(day > 29){
                    return false;
                }else if(day > 28){
                    return false;
                }
            }
        }
        if(month == 4 || month == 6 || month == 9 || month == 11){
            if(day > 30){
                return false;
            }
        }else{
            if(day > 31){
                return false;
            }
        }
        return true;
    } //check if a date is a valid calendar date
}