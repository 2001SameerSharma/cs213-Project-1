package roster;
public enum Major {
    CS, MATH, EE, ITI, BAIT

}